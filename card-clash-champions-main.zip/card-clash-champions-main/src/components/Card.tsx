
import React from 'react';
import { Card as CardType } from '@/types/game';
import { getCardColor, getSuitSymbol } from '@/utils/gameUtils';
import { cn } from '@/lib/utils';

interface CardProps {
  card: CardType | null;
  isFlipped?: boolean;
  className?: string;
  isDealing?: boolean;
  isMatched?: boolean;
}

const Card: React.FC<CardProps> = ({ 
  card, 
  isFlipped = true, 
  className = '',
  isDealing = false,
  isMatched = false
}) => {
  if (!card) {
    return (
      <div className={cn(
        "w-24 h-36 rounded-lg bg-gray-300 flex items-center justify-center",
        className
      )}>
        <span className="text-gray-500">Empty</span>
      </div>
    );
  }

  const cardColor = getCardColor(card.suit);
  const suitSymbol = getSuitSymbol(card.suit);

  return (
    <div 
      className={cn(
        "w-24 h-36 rounded-lg flex items-center justify-center shadow-md relative transition-all duration-300 transform",
        isFlipped ? "bg-white" : "bg-game-purple",
        isDealing && "animate-card-deal",
        isMatched && "animate-card-match",
        className
      )}
    >
      {isFlipped ? (
        <div className="w-full h-full flex flex-col p-2">
          <div className={`text-left ${cardColor}`}>
            <div>{card.rank}</div>
            <div>{suitSymbol}</div>
          </div>
          <div className="flex-grow flex items-center justify-center">
            <div className={`text-4xl ${cardColor}`}>{suitSymbol}</div>
          </div>
          <div className={`text-right ${cardColor} rotate-180`}>
            <div>{card.rank}</div>
            <div>{suitSymbol}</div>
          </div>
        </div>
      ) : (
        <div className="w-full h-full bg-gradient-to-br from-game-purple to-game-dark-purple rounded-lg flex items-center justify-center">
          <span className="text-white text-3xl font-bold">CC</span>
        </div>
      )}
    </div>
  );
};

export default Card;
