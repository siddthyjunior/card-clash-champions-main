
import React, { useState, useEffect } from 'react';
import { Card as CardType } from '@/types/game';
import Card from './Card';
import GameControls from './GameControls';
import ScoreDisplay from './ScoreDisplay';
import { 
  createDeck,
  shuffleDeck,
  cardsMatch
} from '@/utils/gameUtils';
import { updateGameStats } from '@/utils/supbaseUtils';
import { useToast } from '@/hooks/use-toast';

const Game: React.FC = () => {
  // Game state
  const [deck, setDeck] = useState<CardType[]>([]);
  const [playerDeck, setPlayerDeck] = useState<CardType[]>([]);
  const [computerDeck, setComputerDeck] = useState<CardType[]>([]);
  const [poolCards, setPoolCards] = useState<CardType[]>([]);
  const [playerCard, setPlayerCard] = useState<CardType | null>(null);
  const [computerCard, setComputerCard] = useState<CardType | null>(null);
  const [gameOver, setGameOver] = useState(false);
  const [matchAnimation, setMatchAnimation] = useState(false);
  const [dealingAnimation, setDealingAnimation] = useState(false);
  
  const { toast } = useToast();

  // Start new game
  const initializeGame = () => {
    const newDeck = shuffleDeck(createDeck());
    const halfwayPoint = Math.floor(newDeck.length / 2);
    
    setDeck(newDeck);
    setPlayerDeck(newDeck.slice(0, halfwayPoint));
    setComputerDeck(newDeck.slice(halfwayPoint));
    setPoolCards([]);
    setPlayerCard(null);
    setComputerCard(null);
    setGameOver(false);
    setMatchAnimation(false);
  };

  // Deal a card
  const handleDeal = () => {
    if (playerDeck.length === 0) return;
    
    setDealingAnimation(true);

    // Player plays a card
    const newPlayerCard = playerDeck[0];
    const newPlayerDeck = playerDeck.slice(1);
    setPlayerCard(newPlayerCard);
    setPlayerDeck(newPlayerDeck);
    
    // Delay computer play for a better user experience
    setTimeout(() => {
      // Computer plays a card
      if (computerDeck.length > 0) {
        const newComputerCard = computerDeck[0];
        const newComputerDeck = computerDeck.slice(1);
        setComputerCard(newComputerCard);
        setComputerDeck(newComputerDeck);
        
        // Check for match
        const isMatch = cardsMatch(newPlayerCard, newComputerCard);
        
        if (isMatch) {
          setMatchAnimation(true);
          
          // Delay to show the match animation
          setTimeout(() => {
            // Add cards to pool
            const updatedPool = [...poolCards, newPlayerCard, newComputerCard];
            
            // Determine who gets the pool cards
            // In our game, the player always gets matched cards
            setPoolCards([]);
            setPlayerDeck([...newPlayerDeck, ...updatedPool]);
            
            toast({
              title: "Match!",
              description: "You won the pool!",
              variant: "default",
            });
            
            setMatchAnimation(false);
          }, 1000); // After match animation
        } else {
          // No match, add cards to pool
          setPoolCards([...poolCards, newPlayerCard, newComputerCard]);
        }
      }
      
      setDealingAnimation(false);
      
      // Check if game is over
      if (newPlayerDeck.length === 0 || computerDeck.length <= 1) {
        endGame(newPlayerDeck.length > 0);
      }
    }, 500); // Delay for computer's play
  };

  // End game and save results
  const endGame = async (playerWins: boolean) => {
    setGameOver(true);
    
    // Save game result to Supabase
    await updateGameStats(playerWins);
    
    toast({
      title: playerWins ? "Victory!" : "Defeat!",
      description: playerWins 
        ? "Congratulations, you've won the game!" 
        : "You lost this time. Try again!",
      variant: playerWins ? "default" : "destructive",
    });
  };

  // Initialize game on component mount
  useEffect(() => {
    initializeGame();
  }, []);

  return (
    <div className="w-full max-w-2xl mx-auto">
      <ScoreDisplay
        playerCards={playerDeck.length}
        computerCards={computerDeck.length}
        poolCards={poolCards.length}
      />
      
      <div className="flex justify-between mb-8">
        <div className="text-center">
          <h3 className="mb-2 text-white">Computer</h3>
          <div className="relative">
            {computerDeck.length > 0 && (
              <Card card={computerDeck[0]} isFlipped={false} className="opacity-80" />
            )}
            {computerCard && (
              <div className="absolute top-4 left-8">
                <Card 
                  card={computerCard} 
                  isDealing={dealingAnimation} 
                  isMatched={matchAnimation}
                />
              </div>
            )}
          </div>
        </div>
        
        <div className="text-center">
          <h3 className="mb-2 text-white">Pool ({poolCards.length})</h3>
          <div className="relative h-36 w-24 bg-gray-800/20 rounded-lg border-2 border-dashed border-gray-600">
            {poolCards.length > 0 && (
              <div className="absolute -top-2 -left-2">
                <Card card={poolCards[poolCards.length - 1]} />
              </div>
            )}
          </div>
        </div>
        
        <div className="text-center">
          <h3 className="mb-2 text-white">You</h3>
          <div className="relative">
            {playerDeck.length > 0 && (
              <Card card={playerDeck[0]} isFlipped={false} className="opacity-80" />
            )}
            {playerCard && (
              <div className="absolute top-4 left-8">
                <Card 
                  card={playerCard} 
                  isDealing={dealingAnimation}
                  isMatched={matchAnimation} 
                />
              </div>
            )}
          </div>
        </div>
      </div>
      
      <GameControls
        onDeal={handleDeal}
        onReset={initializeGame}
        canDeal={playerDeck.length > 0}
        gameOver={gameOver}
      />
      
      {gameOver && (
        <div className="mt-4 p-4 bg-white/10 rounded-lg text-center text-white">
          <h2 className="text-xl font-bold mb-2">
            {playerDeck.length > computerDeck.length ? "You Won!" : "Computer Won!"}
          </h2>
          <p>Final Score: {playerDeck.length} - {computerDeck.length}</p>
        </div>
      )}
    </div>
  );
};

export default Game;
