
import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { GameStats } from '@/types/game';

interface StatsChartProps {
  stats: GameStats;
}

const StatsChart: React.FC<StatsChartProps> = ({ stats }) => {
  const data = [
    { name: 'Wins', value: stats.wins, color: '#9b87f5' },
    { name: 'Losses', value: stats.losses, color: '#F97316' }
  ];

  // If no games played, show placeholder
  if (stats.wins === 0 && stats.losses === 0) {
    return (
      <div className="w-full h-64 bg-gray-100 rounded-lg flex items-center justify-center">
        <p className="text-gray-500">Play a game to see your stats!</p>
      </div>
    );
  }

  return (
    <div className="w-full h-64 bg-white rounded-lg shadow-md p-4">
      <h3 className="text-lg font-semibold mb-2 text-center">Game Statistics</h3>
      <ResponsiveContainer width="100%" height="80%">
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            labelLine={false}
            outerRadius={80}
            fill="#8884d8"
            dataKey="value"
            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Pie>
          <Tooltip formatter={(value) => [`${value} games`, null]} />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
};

export default StatsChart;
