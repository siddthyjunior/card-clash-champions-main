
import React from 'react';
import { Button } from '@/components/ui/button';
import { PlayCircle, Shuffle } from 'lucide-react';

interface GameControlsProps {
  onDeal: () => void;
  onReset: () => void;
  canDeal: boolean;
  gameOver: boolean;
}

const GameControls: React.FC<GameControlsProps> = ({ 
  onDeal, 
  onReset, 
  canDeal, 
  gameOver 
}) => {
  return (
    <div className="flex gap-4 justify-center my-4">
      <Button 
        onClick={onDeal} 
        disabled={!canDeal || gameOver}
        className="bg-game-purple hover:bg-game-dark-purple"
      >
        <PlayCircle className="mr-2 h-4 w-4" /> Deal Card
      </Button>
      <Button 
        onClick={onReset}
        variant="outline" 
        className="border-game-purple text-game-purple hover:bg-game-light-purple/20"
      >
        <Shuffle className="mr-2 h-4 w-4" /> New Game
      </Button>
    </div>
  );
};

export default GameControls;
