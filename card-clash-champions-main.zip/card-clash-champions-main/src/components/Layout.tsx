
import React from 'react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { PlayCircle, ChartPie } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-game-bg to-game-dark-purple">
      <header className="p-4 bg-white/5 backdrop-blur-sm">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold text-white">Card Clash Champions</h1>
          <nav className="flex gap-4">
            <Link to="/">
              <Button variant="ghost" className="text-white">
                <PlayCircle className="mr-2 h-4 w-4" />
                Play
              </Button>
            </Link>
            <Link to="/stats">
              <Button variant="ghost" className="text-white">
                <ChartPie className="mr-2 h-4 w-4" />
                Stats
              </Button>
            </Link>
          </nav>
        </div>
      </header>
      <main className="container mx-auto p-4 mt-4">
        {children}
      </main>
    </div>
  );
};

export default Layout;
