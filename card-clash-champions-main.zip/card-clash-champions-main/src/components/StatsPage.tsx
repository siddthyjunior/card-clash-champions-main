
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import StatsChart from './StatsChart';
import { GameStats } from '@/types/game';
import { ChartPie } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { fetchGameStats } from '@/utils/supbaseUtils';
import { supabase } from "@/integrations/supabase/client";

const StatsPage: React.FC = () => {
  const [stats, setStats] = useState<GameStats>({ wins: 0, losses: 0, gamesPlayed: 0 });
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    const loadStats = async () => {
      setIsLoading(true);
      const gameStats = await fetchGameStats();
      setStats(gameStats);
      setIsLoading(false);
    };

    loadStats();
  }, []);

  const handleReset = async () => {
    try {
      setIsLoading(true);
      
      // Reset stats in Supabase
      const { error } = await supabase
        .from('game_stats')
        .update({ wins: 0, losses: 0, games_played: 0, updated_at: new Date().toISOString() })
        .is('user_id', null);
        
      if (error) throw error;
      
      // Update local state
      setStats({ wins: 0, losses: 0, gamesPlayed: 0 });
      
      toast({
        title: "Stats Reset",
        description: "Your game statistics have been reset.",
      });
    } catch (error) {
      console.error('Error resetting stats:', error);
      toast({
        title: "Error",
        description: "Failed to reset statistics. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto bg-white/5 p-6 rounded-lg">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <ChartPie className="h-6 w-6 text-game-purple mr-2" />
          <h2 className="text-xl font-bold text-white">Game Statistics</h2>
        </div>
        <Button 
          variant="outline" 
          onClick={handleReset}
          disabled={isLoading}
          className="border-game-purple text-game-purple hover:bg-game-light-purple/20"
        >
          Reset Stats
        </Button>
      </div>
      
      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <p className="text-white/70">Loading statistics...</p>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <div className="bg-white/10 p-4 rounded-lg text-center">
              <h3 className="text-white/70 text-sm mb-1">Games Played</h3>
              <p className="text-white text-2xl font-bold">{stats.gamesPlayed}</p>
            </div>
            <div className="bg-white/10 p-4 rounded-lg text-center">
              <h3 className="text-white/70 text-sm mb-1">Wins</h3>
              <p className="text-game-purple text-2xl font-bold">{stats.wins}</p>
            </div>
            <div className="bg-white/10 p-4 rounded-lg text-center">
              <h3 className="text-white/70 text-sm mb-1">Losses</h3>
              <p className="text-game-accent text-2xl font-bold">{stats.losses}</p>
            </div>
          </div>
          
          <StatsChart stats={stats} />
          
          <div className="mt-6 text-white/70 text-sm">
            <p>Win rate: {stats.gamesPlayed > 0 
              ? `${((stats.wins / stats.gamesPlayed) * 100).toFixed(1)}%` 
              : '0%'}
            </p>
          </div>
        </>
      )}
    </div>
  );
};

export default StatsPage;
