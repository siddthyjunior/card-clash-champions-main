
import React from 'react';

interface ScoreDisplayProps {
  playerCards: number;
  computerCards: number;
  poolCards: number;
}

const ScoreDisplay: React.FC<ScoreDisplayProps> = ({ 
  playerCards, 
  computerCards, 
  poolCards 
}) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-4 grid grid-cols-3 gap-4 mb-4">
      <div className="text-center">
        <h3 className="text-sm text-gray-500">Your Cards</h3>
        <p className="text-2xl font-bold text-game-purple">{playerCards}</p>
      </div>
      <div className="text-center">
        <h3 className="text-sm text-gray-500">Pool</h3>
        <p className="text-2xl font-bold text-game-accent">{poolCards}</p>
      </div>
      <div className="text-center">
        <h3 className="text-sm text-gray-500">Computer Cards</h3>
        <p className="text-2xl font-bold text-red-500">{computerCards}</p>
      </div>
    </div>
  );
};

export default ScoreDisplay;
