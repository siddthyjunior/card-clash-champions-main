
import { supabase } from "@/integrations/supabase/client";
import { GameStats } from "@/types/game";

// Fetch game stats from Supabase
export const fetchGameStats = async (): Promise<GameStats> => {
  try {
    // For anonymous users, we'll use the record with null user_id
    const { data, error } = await supabase
      .from('game_stats')
      .select('wins, losses, games_played')
      .is('user_id', null)
      .single();
    
    if (error) {
      console.error('Error fetching game stats:', error);
      return { wins: 0, losses: 0, gamesPlayed: 0 };
    }
    
    return { 
      wins: data.wins, 
      losses: data.losses, 
      gamesPlayed: data.games_played 
    };
  } catch (error) {
    console.error('Error in fetchGameStats:', error);
    return { wins: 0, losses: 0, gamesPlayed: 0 };
  }
};

// Update game stats in Supabase
export const updateGameStats = async (playerWon: boolean): Promise<void> => {
  try {
    // First get the current stats
    const { data, error } = await supabase
      .from('game_stats')
      .select('id, wins, losses, games_played')
      .is('user_id', null)
      .single();
    
    if (error) {
      console.error('Error fetching game stats for update:', error);
      return;
    }
    
    // Update the stats
    const newStats = {
      wins: data.wins + (playerWon ? 1 : 0),
      losses: data.losses + (playerWon ? 0 : 1),
      games_played: data.games_played + 1,
      updated_at: new Date().toISOString()
    };
    
    const { error: updateError } = await supabase
      .from('game_stats')
      .update(newStats)
      .eq('id', data.id);
      
    if (updateError) {
      console.error('Error updating game stats:', updateError);
    }
  } catch (error) {
    console.error('Error in updateGameStats:', error);
  }
};
