
import { Card, CardRank, CardSuit } from "@/types/game";

// Create a new deck of cards
export const createDeck = (): Card[] => {
  const suits: CardSuit[] = ['hearts', 'diamonds', 'clubs', 'spades'];
  const ranks: CardRank[] = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
  const deck: Card[] = [];

  for (const suit of suits) {
    for (const rank of ranks) {
      deck.push({
        suit,
        rank,
        id: `${rank}-${suit}`
      });
    }
  }

  return deck;
};

// Shuffle the deck using Fisher-Yates algorithm
export const shuffleDeck = (deck: Card[]): Card[] => {
  const newDeck = [...deck];
  for (let i = newDeck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newDeck[i], newDeck[j]] = [newDeck[j], newDeck[i]];
  }
  return newDeck;
};

// Check if two cards match (same rank or same suit)
export const cardsMatch = (card1: Card | null, card2: Card | null): boolean => {
  if (!card1 || !card2) return false;
  return card1.rank === card2.rank || card1.suit === card2.suit;
};

// Get card color based on suit
export const getCardColor = (suit: CardSuit): string => {
  return suit === 'hearts' || suit === 'diamonds' ? 'text-red-600' : 'text-black';
};

// Get suit symbol
export const getSuitSymbol = (suit: CardSuit): string => {
  switch (suit) {
    case 'hearts': return '♥';
    case 'diamonds': return '♦';
    case 'clubs': return '♣';
    case 'spades': return '♠';
  }
};

// Computer play logic - basic version
export const computerPlay = (
  playerCard: Card | null, 
  poolCard: Card | null, 
  computerDeck: Card[]
): Card | null => {
  if (computerDeck.length === 0) return null;
  return computerDeck[0]; // Simply play the top card
};

// Save game stats to localStorage
export const saveGameStats = (win: boolean): void => {
  const statsStr = localStorage.getItem('cardClashStats');
  let stats = statsStr ? JSON.parse(statsStr) : { wins: 0, losses: 0, gamesPlayed: 0 };
  
  if (win) {
    stats.wins += 1;
  } else {
    stats.losses += 1;
  }
  
  stats.gamesPlayed += 1;
  
  localStorage.setItem('cardClashStats', JSON.stringify(stats));
};

// Load game stats from localStorage
export const loadGameStats = () => {
  const statsStr = localStorage.getItem('cardClashStats');
  if (statsStr) {
    return JSON.parse(statsStr);
  }
  return { wins: 0, losses: 0, gamesPlayed: 0 };
};

// Reset game stats in localStorage
export const resetGameStats = () => {
  localStorage.setItem('cardClashStats', JSON.stringify({ wins: 0, losses: 0, gamesPlayed: 0 }));
};
